<?php
session_start();
class DbConnection{                                  //Importing the DatabaseConnection file.
    public $conn;                                    
    public function __construct(){
        $conn=new mysqli("localhost","root","root","userdetails");
        if(!$conn){
            die("Cannot Connect To The Database");
        }    
        else{
            
        }                                           
    }
}                                               
class DbFunction{
    public function checkUser($email,$password){
        $connection=new DbConnection();
        $sql=mysqli_query($connection->conn,"select * from login where email='".$email."' and password='".$password."'");
        $userData=mysqli_fetch_array($sql);
        $noOfRows=mysqli_num_rows($sql);
        if($noOfRows==1){
            $_SESSION['login']='true';
            $_SESSION['userId']=$userData['id'];
            $_SESSION['userName']=$userData['username'];
            $_SESSION['userEmail']=$userData['email'];
            return true;
        }
        else{
            return false;
        }
    }
    public function createUser($username,$email,$password){
        $connection=new DbConnection();
        $sql=mysqli_query($connection->conn,"insert into login(username,email,password) values('".$username."','".$email."','".$password."')");
        return $sql;
    }
    public function isUserExists($email){
        $connection=new DbConnection();
        $sql=mysqli_query($connection->conn,"select * from login  where email='".$email."'");
        if(mysqli_num_rows($sql)>0){
            return true;
        }
        else{
            return false;
        }
    }
}
?>