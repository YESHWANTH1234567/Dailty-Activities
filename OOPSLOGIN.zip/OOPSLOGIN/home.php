<?php
include_once("function.php");   
// print_r($_SESSION['userName']);
// exit();
if(isset($_POST['logout'])){
    session_unset();
    session_destroy();
    if(!($_SESSION)){
        header("location:Index.php");
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Welcome Page</title>
        <style>
            .center{                                        /*To allocate the form in center position with backgroud.*/
                background-image: url("images/form.jfif");
                background-repeat: no-repeat;
                background-size: 100%;
                margin: auto;
                position:relative;
                top: 50px;
                width: 30%; 
                height: 100px;
                padding: 30px;
            }
            h2{
                margin:auto;
            }
            .type{                          /*To design login button*/
                background-color:gray;
                color: white;
                padding: 10px 15px;
                width: 30%;
                margin: 5px 0;
                border: none;
                cursor: pointer; 
            }
        </style>
    </head>
    <body>
        <h2>Welcome <?php echo $_SESSION['userName'] ?>
        <div class="center">
            <form action="home.php" method="POST">
                <lable>Your UserName: </lable>
                <?php  echo $_SESSION['userName']?><br>
                <lable>Your Email:    </label>
                <?php echo $_SESSION['userEmail']?>
                <input type="submit" value ="logout" name="logout" class="type">
            </form>
        </div>
    </body>
</html>