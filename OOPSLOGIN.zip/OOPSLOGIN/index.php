<?php                          
    if(isset($_POST["login"])){                   //importing the function.php file.
        include_once("DbFunction.php");                                                     
        $object=new DbFunction();                     //Creating the object for DbFunction class.
        
        $email=$_POST['email'];
        $password=$_POST['password'];
        $user=$object->checkUser($email,$password);

        if($user){
            header("location:home.php");
        }else{
            echo "<script>alert('email/password is incorrect')</script>";
        }
    }
?>
<!DOCTYPE html>
    <head>
        <title>Login Form</title>
        <link rel="stylesheet" href="css files/bootstrap.css">
        <style>
            .center{                                        /*To allocate the form in center position with backgroud.*/
                background-image: url("images/form.jfif");
                background-repeat: no-repeat;
                background-size: 100%;
                margin: auto;
                position:relative;
                top: 50px;
                width: 50%; 
                height: 400px;
                padding: 30px;
            }
            .type{                            /*To design login button*/
                background-color:gray;
                color: white;
                padding: 10px 15px;
                width: 100%;
                margin: 5px 0;
                border: none;
                cursor: pointer;
            }
            .link{                                     /* to design Link */
                background-color: greenyellow;
                color:blue;
                padding:5px 10px;
                width: 100%;
            }
        </style>
    </head>
    <body>
        <div class="center">
            <h2>Welcome to Clarity tts</h2>
                <form action="index.php" method="POST" >
                    <div class="form-group">
                        <label>Email:</label>
                        <input type="text" class="form-control" name="email" onblur="validateEmail()">
                    </div>
                    <div class="form-group">
                        <label>Password:</label>
                        <input class="form-control" type="password" name="password" onblur="validatePassword()">
                    </div><br>
                        <input type="submit" name="login" class="type">
                    <a href="Register.php" class="link">New Register</a>
                </form>
        </div>
    </body>
</html>





