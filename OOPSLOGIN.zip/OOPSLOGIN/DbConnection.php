<?php
class DbConnection{                                  //Importing the DatabaseConnection file.
    public $conn;                                    
    public function __construct(){
        $this->conn=mysqli_connect("localhost","root","","userdetails");
        if(!$this->conn){
            die("Cannot Connect To The Database");
        }                                               
    }
}                                               
?>