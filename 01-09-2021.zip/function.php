<?php
session_start();

class DbConnection                                     //Importing the DatabaseConnection file.
{                                                     
    public $conn;                                    
    public function __construct()
    {
        $this->conn=mysqli_connect("localhost","root","","userdetails");
        if(!$this->conn)
        {
            die("Cannot Connect To The Database");
        }
    
    }
}



class DbFunction
{
    
    
   
    public function login($email,$password)
    {
        $connection=new DbConnection();
        $sql=mysqli_query($connection->conn,"select * from login where email='".$email."' and password='".$password."'");
        $userData=mysqli_fetch_array($sql);
        $noOfRows=mysqli_num_rows($sql);
        if($noOfRows==1)
        {
            $_SESSION['login']='true';
            $_SESSION['userId']=$userData['id'];
            $_SESSION['userName']=$userData['username'];
            $_SESSION['userEmail']=$userData['email'];
            return true;
        }
        else
        {
            return false;
        }
    }
    public function userRegister($username,$email,$password)
    {
        $connection=new DbConnection();
        $sql=mysqli_query($connection->conn,"insert into login(username,email,password) values('".$username."','".$email."','".$password."')");
        return $sql;
    }
    public function isUserExists($email)
    {
        $connection=new DbConnection();
        $sql=mysqli_query($connection->conn,"select * from login  where email='".$email."'");
        if(mysqli_num_rows($sql)>0)
        {
            return true;
        }
        else{
            return false;
        }
    }
}


?>





