
<?php

include_once("function.php");                                //importing the function.php file.

if(isset($_POST["login"]))
{
                                                              
    $object=new DbFunction();                     //Creating the object for DbFunction class.
    
    $email=$_POST['email'];
    $password=$_POST['password'];
    $user=$object->login($email,$password);
    if($user)
    {
        header("location:home.php");
    }
    else
    {
        echo "<script>alert('email/password is incorrect')</script>";
    }

}

?>
    




<!DOCTYPE html>
<html>
    <head>
        <title>Login Form</title>
        <link rel="stylesheet" href="css files/bootstrap.css">
        <style>
            .center                                        /*To allocate the form in center position with backgroud.*/
            {
                background-image: url("images/form.jfif");
                background-repeat: no-repeat;
                background-size: 100%;
                margin: auto;
                position:relative;
                top: 50px;
                width: 30%; 
                height: 400px;
                padding: 30px;
            }
            .type                             /*To design login button*/
            {
                background-color:gray;
                color: white;
                padding: 10px 15px;
                width: 100%;
                margin: 5px 0;
                border: none;
                cursor: pointer;
                

            }
            .link                                     /* to design Link */
            {
                background-color: greenyellow;
                color:blue;
                padding:5px 10px;
                width: 100%;
            }
        </style>
    </head>
    <body>
        <div class="center">
           
                <h2>Welcome to Clarity tts</h2>
                <form action="Index.php" method="POST" >
                    <div class="form-group">
                        <label>Email:</label>
                        <input type="text" class="form-control" name="email" onblur="validateEmail(this);">
                    </div>
                    <div class="form-group">
                        <label>Password:</label>
                        <input class="form-control" type="password" name="password" onblur="validatePassword(this);">
                    </div>
                    <br>
                    <input type="submit" name="login" class="type">
                    <a href="Register.php" class="link">New Register</a>
                </form>
            </div>
        </div>



    </body>
</html>


<script>

function validateEmail(emailField)
{
    var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
    if(reg.test(emailField)==false)
    {
        $("#message").html("<li>Inavalid Email Address</li>");
        return false;
    }
    $("#message").html("");
    return true;
}

function validatePassword(passwordField)
{
    var reg= /^[a-zA-Z0-9!@#$%^&*]{6,16}$/;
    if(reg.test(passwordField)==false)
    {
        $("#message").html("<li>Invalid Password</li>");
        return false;
    }
    $("#message").html("");
    return true;
}


$(document).ready(function()
{
  $("#checkValidation").click(function()
    {
        var username = $("#email").val().trim();
        var password = $("#password").val().trim();
        $.ajax(
        {
        url:'showData.php',
        type:'post',
        data:{username:username,password:password},
        success:function(response)
        {
            $("#message").html(response);

        }
        });
    });
});






</script>





