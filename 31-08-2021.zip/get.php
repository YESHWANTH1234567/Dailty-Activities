
<?php

include_once("function.php");                     //importing the function.php file.

$object=new DbFunction();                     //Creating the object for DbFunction class.

if($_POST['register'])
{
    $username=$_POST['username'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $confirmpassword=$_POST['cfmpassword'];
    if($password==$confirmpassword)
    {
        $emailExits=$object->isUserExists($email);
        if(!$emailExits)
        {
            $register=$object->userRegister($username,$email,$password);
            if($register)
            {
                echo "records inserted successfully";
            }
            else
            {
                echo "Error Occured";
            }
        }
        else{
            echo "<script>alert('Email already Exists')</script>";
        }
        
    }
    else
    {
        echo "password does't match";
    }
}

?>
    

