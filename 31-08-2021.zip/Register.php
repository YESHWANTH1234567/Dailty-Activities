<!DOCTYPE html>
<html>
    <head>
        <title>Registration form</title>
        <link rel="stylesheet" href="bootstrap.css">
        
        <style>

            .center                                        /*To allocate the form in center position with backgroud.*/
            {
                background-image: url("images/form.jfif");
                background-repeat: no-repeat;
                background-size: 100%;
                margin: auto;
                position:relative;
                top: 50px;
                width: 30%; 
                height: 600px;
                padding: 30px;
                color:blue;
            }
            button                             /*To design login button*/
            {
                background-color:gray;
                color: white;
                padding: 10px 15px;
                width: 100%;
                margin: 5px 0;
                border: none;
                cursor: pointer;
                

            }
            .type                             /*To design login button*/
            {
                background-color:gray;
                color: white;
                padding: 10px 15px;
                width: 100%;
                margin: 5px 0;
                border: none;
                cursor: pointer;
                

            }
            .link                                     /* to design Link */
            {
                background-color: greenyellow;
                color:blue;
                padding:5px 10px;
                width: 50%;
            }
        </style>
    </head>
    <body>
        <div class="center">
                <h2>Welcome to Clarity tts</h2>
                <form action="get.php" method="POST" >
                    <div class="form-group">
                        <label>UserName:</label>
                        <input type="text" class="form-control" name="username" required>
                    </div>
                    <div class="form-group">
                        <label>Email:</label>
                        <input type="text" class="form-control" name="email" required>
                    </div>
                    <div class="form-group">
                        <label>Password:</label>
                        <input class="form-control" type="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label>Confirm Password:</label>
                        <input class="form-control" type="password" name="cfmpassword" required>
                    </div>
                    <br>
                    <input type="submit" class="type" name="register">
                    <p>already a member
                    <a href="Register.php" class="link">log_in</a>
                    </p>            
                        
                </form>
        </div>
    </body>
</html>
