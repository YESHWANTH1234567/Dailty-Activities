
<?php

include_once("function.php");                     //importing the function.php file.

$object=new DbFunction();                     //Creating the object for DbFunction class.

if($_POST['login'])
{
    $email=$_POST['email'];
    $password=$_POST['password'];
    $user=$object->login($email,$password);
    if($user)
    {
        header("location:home.php");
    }
    else
    {
        echo "<script>alert('email/password is incorrect')</script>";
    }
}

?>
    

